## API.md

api key = AIzaSyCa-hcsWEb7UzSQeXCW54tCFI1b8JpQNFI

GLM API Key = fb58dcc93ce0474a97d2b18ff99fb782.BhgPesvzm8YbkCfW

openai api key = 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